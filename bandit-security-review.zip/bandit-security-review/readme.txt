﻿■ Secure Coding Review – Python Project

■ Objective
To demonstrate how to:
- Detect insecure code using Bandit
- Understand what Bandit flags
- Rewrite the code in a secure way
- Compare both versions and explain the difference
■ Tools Used
■ Python 3.x
■ Bandit (Static Code Analyzer)
■ bcrypt (for secure password hashing)
■ subprocess (for safe system commands)
■■ Installation Instructions
Install Bandit:
pip install bandit
Install bcrypt:
pip install bcrypt
Run Bandit:
bandit bad_code.py

■ Example 1: Insecure Code (bad_code.py)
import hashlib
import os

# Insecure MD5 hashing
def store_password(password):
    return hashlib.md5(password.encode()).hexdigest()

# Insecure command execution
def delete_user_data(username):
    os.system("rm -rf /home/" + username)

password = input("Enter your password: ")
hashed = store_password(password)
print("Stored password hash:", hashed)

delete_user_data("demo_user")

■ What Bandit Detects:
B303 – Use of weak hash function (MD5)
B605 – Possible command injection via os.system
■ Example 2: Secure Version (secure_code.py)
import bcrypt
import subprocess

# Secure bcrypt hashing
def store_password(password):
    salt = bcrypt.gensalt()



    return bcrypt.hashpw(password.encode(), salt)

# Safe subprocess call
def delete_user_data(username):
    try:
        subprocess.run(["rm", "-rf", f"/home/{username}"], check=True)
    except Exception as e:
        print("Error deleting user data:", e)

password = input("Enter your password: ")
hashed = store_password(password)
print("Stored password hash:", hashed)

delete_user_data("demo_user")

■ Security Improvements:
• Passwords hashed using bcrypt
• Avoids command injection by using subprocess.run()
• Added error handling
■ Conclusion
Bandit is great for catching known insecure functions.
It doesn’t catch logic flaws like storing plaintext passwords — that requires manual code review.
This project shows how secure coding practices improve both safety and reliability.
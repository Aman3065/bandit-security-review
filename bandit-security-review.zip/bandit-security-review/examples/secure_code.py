import bcrypt
import subprocess

# Secure password hashing using bcrypt
def store_password(password):
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode(), salt)

# Safer subprocess call with argument list
def delete_user_data(username):
    try:
        subprocess.run(["rm", "-rf", f"/home/{username}"], check=True)
    except Exception as e:
        print("Error deleting user data:", e)

password = input("Enter your password: ")
hashed = store_password(password)
print("Stored password hash:", hashed)

delete_user_data("demo_user")

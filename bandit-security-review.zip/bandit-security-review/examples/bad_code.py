import hashlib
import os

# Insecure password hashing using MD5
def store_password(password):
    return hashlib.md5(password.encode()).hexdigest()

# Insecure use of system command
def delete_user_data(username):
    os.system("rm -rf /home/" + username)

password = input("Enter your password: ")
hashed = store_password(password)
print("Stored password hash:", hashed)

delete_user_data("demo_user")
